
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.*;

public class DbController {

    private Connection connection;
    private ResultSet resultSet;
    private Statement statement;
    private PreparedStatement ps;

    public void dbaseConnect(String url, String user, String pass) throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        connection = DriverManager.getConnection(url, user, pass);
    }

    public ResultSet getAdminAccounts(String username, String password) throws Exception {
        String sql = "select * \n"
                + "from admin natural join accounts\n"
                + "where username = ? and password = ?;";
        ps = connection.prepareStatement(sql);
        ps.setString(1, username);
        ps.setString(2, password);
        return ps.executeQuery();
    }

    public void close() {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (Exception e) {

        }
    }

    /*Encryption*/
    public String sha1(String input) throws NoSuchAlgorithmException {
        MessageDigest mDigest;
        mDigest = MessageDigest.getInstance("SHA1");
        byte[] result = mDigest.digest(input.getBytes());
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < result.length; i++) {
            sb.append(Integer.toString((result[i] & 0xff) + 0x100, 16).substring(1));
        }

        return sb.toString();
    }
}
