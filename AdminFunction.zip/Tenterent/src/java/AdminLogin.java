/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet(name="AdminLogin", urlPatterns = {"/admin_login", "/AdminLogin"})
public class AdminLogin extends HttpServlet {

    private static DbController controller;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            controller = new DbController();
            String url = "jdbc:mysql://localhost/tenterent?useSSL=false";
            controller.dbaseConnect(url, "root", null);

            password = controller.sha1(password);
            ResultSet rs = controller.getAdminAccounts(username, password);

            if (rs.next()) {
                String name = rs.getString("admin_name");
                String contact = rs.getString("admin_contact");
                String email = rs.getString("email");

                HttpSession session = request.getSession(true);
                session.setAttribute("name", name);
                session.setAttribute("contact", contact);
                session.setAttribute("email", email);
                session.setAttribute("username", username);
                session.setAttribute("password", password);
                
                response.sendRedirect("index");
            } else {
                out.println("Invalid user credentials!");

            }

        } catch (SQLException e) {
            System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
        } catch (Exception e) {
            System.err.println("error: " + e.getClass() + "\n" + e.getMessage());
        } finally {
            controller.close();
        }

    }

}
