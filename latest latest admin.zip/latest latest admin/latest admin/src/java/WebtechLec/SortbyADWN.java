/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WebtechLec;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author james
 */
@WebServlet(name = "SortbyADWN", urlPatterns = {"/SortbyADWN"})
public class SortbyADWN extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
            response.setContentType("text/html;charset=UTF-8");
            response.setContentType("text/html");
            try (PrintWriter out = response.getWriter()) {
            RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/pagefragments/Aheader.html");
            rd.include(request, response);
            HttpSession session = request.getSession(false);
            if(session == null){
                response.sendRedirect("index.html");  
            }else {
            ConnectDB db = new ConnectDB();
            Connection conn = db.getConn();
            String stmt;
            stmt = "select first_name, last_name,address, birthdate, contact_number from customer;";
                out.println("<h1>Customer User Information List</h1><br>");
                PreparedStatement ps = conn.prepareStatement(stmt);
                ResultSet rs = ps.executeQuery();
                String table = "    <table>"
                        + "     <tr>"
                        + "         <th align=\"right\"><a href=\"SortbyCFN\">First Name</a></th>"
                        + "         <th align=\"right\"><a href=\"SortbyCLN\">Last Name</a></th>"
                        + "         <th align=\"right\">Address</th>"
                        + "         <th align=\"right\">Birthdate</th>"
                        + "         <th align=\"right\">Contact Number</th>"
                        + "     </tr>";
                out.println(table);
                while(rs.next()){
                    out.println("           <tr>");
                    out.println("               <td>"+rs.getString("first_name")+"</td>");
                    out.println("               <td>"+rs.getString("last_name")+"</td>");
                    out.println("               <td>"+rs.getString("address")+"</td>");
                    out.println("               <td>"+rs.getString("birthdate")+"</td>");
                    out.println("               <td>"+rs.getString("contact_number")+"</td>");
                    out.println("           </tr>");
                }
                out.println("   </table>");
                stmt = "select admin_name, admin_contact from admin order by admin_name DESC;";
                out.println("<h1>Admin User Information List</h1><br>");
                PreparedStatement ps2 = conn.prepareStatement(stmt);
                ResultSet rs2 = ps2.executeQuery();
                String table2 = "    <table>"
                        + "     <tr>"
                        + "         <th align=\"right\"><a href=\"SortbyANS\">Admin Name&nbsp&nbsp&nbsp &darr;</th>"
                        + "         <th align=\"right\">Admin Contact</th>"
                        + "     </tr>";
                out.println(table2);
                while(rs2.next()){
                    out.println("           <tr>");
                    out.println("               <td>"+rs2.getString("admin_name")+"</td>");
                    out.println("               <td>"+rs2.getString("admin_contact")+"</td>");
                    out.println("           </tr>");
                }
                out.println("   </table>");
                stmt = "select provider_name, provider_contact, provider_address from service_provider;";
                out.println("<h1>Service Provider User Information List</h1><br>");
                PreparedStatement ps3 = conn.prepareStatement(stmt);
                ResultSet rs3 = ps3.executeQuery();
                String table3 = "    <table>"
                        + "     <tr>"
                        + "         <th align=\"right\">Service Provider Name</th>"
                        + "         <th align=\"right\">Service Provider Contact</th>"
                        + "         <th align=\"right\">Service Provider Address</th>"
                        + "     </tr>";
                out.println(table3);
                while(rs3.next()){
                    out.println("           <tr>");
                    out.println("               <td>"+rs3.getString("provider_name")+"</td>");
                    out.println("               <td>"+rs3.getString("provider_contact")+"</td>");
                    out.println("               <td>"+rs3.getString("provider_address")+"</td>");
                    out.println("           </tr>");
                }
        }
    }
  }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(SortbyCLN.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (SQLException ex) {
            Logger.getLogger(SortbyCLN.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
